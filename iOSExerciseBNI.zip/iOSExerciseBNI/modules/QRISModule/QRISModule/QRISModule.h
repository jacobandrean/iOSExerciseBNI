//
//  QRISModule.h
//  QRISModule
//
//  Created by J Andrean on 19/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for QRISModule.
FOUNDATION_EXPORT double QRISModuleVersionNumber;

//! Project version string for QRISModule.
FOUNDATION_EXPORT const unsigned char QRISModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QRISModule/PublicHeader.h>


