//
//  ScanQRPresenter.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Foundation

protocol ScanQRPresentationLogic {
    var viewController: ScanQRDisplayLogic? { get set }
    var router: ScanQRRouting? { get set }
    
    func finishScanQR()
}

class ScanQRPresenter: ScanQRPresentationLogic {
    weak var viewController: ScanQRDisplayLogic?
    var router: ScanQRRouting?
    
    func finishScanQR() {
        router?.dismissToQRISLanding()
    }
}
