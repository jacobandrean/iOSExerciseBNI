//
//  ScanQRInteractor.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Combine
import Foundation
import InjectorModule
import UtilityModule

protocol ScanQRBusinessLogic {
    var presenter: ScanQRPresentationLogic! { get set }
}

class ScanQRInteractor: ScanQRBusinessLogic {
    var presenter: ScanQRPresentationLogic!
}
