//
//  ScanQRRouter.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Foundation
import InjectorModule
import UIKit
import UtilityModule

protocol ScanQRRouting: Routing {
    func dismissToQRISLanding()
}

class ScanQRRouter: ScanQRRouting {
    var baseVC: UIViewController?
    
    func dismissToQRISLanding() {
        baseVC?.dismiss(animated: true)
    }
}
