//
//  ScanQRViewController.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import AVFoundation
import UIKit
import UIModule

public protocol ScanQRDelegate: AnyObject {
    func didScanQRCodeWithData(_ data: String)
}

protocol ScanQRDisplayLogic: AnyObject {
    var interactor: ScanQRBusinessLogic! { get set }
    var presenter: ScanQRPresentationLogic! { get set}
    var scanQRDelegate: ScanQRDelegate? { get set }
}

class ScanQRViewController: BaseVC, ScanQRDisplayLogic, AVCaptureMetadataOutputObjectsDelegate {
    
    weak var scanQRDelegate: ScanQRDelegate?
    var interactor: ScanQRBusinessLogic!
    var presenter: ScanQRPresentationLogic!
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    
    override var prefersStatusBarHidden: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        checkCameraAuthorizationStatus()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    func checkCameraAuthorizationStatus() {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        switch status {
        case .authorized:
            startScanning()
        case .notDetermined:
            requestCameraAccess()
        case .denied, .restricted:
            showSettingsAlert()
        @unknown default:
            fatalError("Unknown AVCaptureDeviceAuthorizationStatus case")
        }
    }

    func requestCameraAccess() {
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            if granted {
                self?.startScanning()
            } else {
                self?.showSettingsAlert()
            }
        }
    }

    func showSettingsAlert() {
        let alert = UIAlertController(
            title: "Camera Access Denied",
            message: "Please allow camera access for scanning QR codes. Go to Settings -> Privacy -> Camera to enable.",
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
        })

        present(alert, animated: true, completion: nil)
    }
    
    func startScanning() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            captureSession = AVCaptureSession()
            
            guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
                fatalError("No video capture device available")
            }
            
            guard let videoInput = try? AVCaptureDeviceInput(device: videoCaptureDevice) else {
                fatalError("Unable to create input from video capture device")
            }
            
            guard let captureSession else {
                fatalError("Missing captureSession")
            }
            
            let metadataOutput = AVCaptureMetadataOutput()
            
            guard captureSession.canAddInput(videoInput),
                  captureSession.canAddOutput(metadataOutput) else {
                fatalError("Unable to add input or output to capture session")
            }
            
            captureSession.addInput(videoInput)
            captureSession.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.qr]
            
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                previewLayer.videoGravity = .resizeAspectFill
                previewLayer.frame = view.layer.bounds
                view.layer.addSublayer(previewLayer)
            }
            
            captureSession.startRunning()
        }
    }


    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard let metadataObject = metadataObjects.first,
              let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject,
              let stringValue = readableObject.stringValue
        else { return }
        
        scanQRDelegate?.didScanQRCodeWithData(stringValue)
        captureSession.stopRunning()
        presenter.finishScanQR()
    }
}

