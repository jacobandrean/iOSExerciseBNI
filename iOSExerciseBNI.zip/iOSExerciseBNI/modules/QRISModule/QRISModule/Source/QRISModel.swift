//
//  QRISModel.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Foundation
import UtilityModule

struct TransactionData: Codable {
    @RupiahFormat var balance = 0
    var transactionHistory: [Transaction]
}

struct Transaction: Codable, Hashable {
    var uniqueID = UUID()
    var destBank: String?
    var trxID: String?
    var merchantName: String?
    @RupiahFormat var amountToPay = 0
    
    static func == (lhs: Transaction, rhs: Transaction) -> Bool {
        return lhs.destBank == rhs.destBank &&
        lhs.trxID == rhs.trxID &&
        lhs.merchantName == rhs.merchantName &&
        lhs.amountToPay == rhs.amountToPay &&
        lhs.uniqueID == rhs.uniqueID
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(destBank)
        hasher.combine(trxID)
        hasher.combine(merchantName)
        hasher.combine(amountToPay)
        hasher.combine(uniqueID)
    }
}
