//
//  QRISLandingRouter.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Foundation
import InjectorModule
import UIKit
import UtilityModule

protocol QRISLandingRouting: Routing {
    func showScanQRModal(delegate: ScanQRDelegate?)
}

class QRISLandingRouter: QRISLandingRouting {
    var baseVC: UIViewController?
    
    @Inject var qrisFactory: QRISFactory
    
    func showScanQRModal(delegate: ScanQRDelegate?) {
        let viewController = qrisFactory.createScanQRVC(delegate: delegate)
        try? route(.present(animated: true), for: viewController)
    }
}
