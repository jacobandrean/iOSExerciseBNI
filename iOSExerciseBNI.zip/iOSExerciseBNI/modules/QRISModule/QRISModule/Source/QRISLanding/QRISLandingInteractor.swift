//
//  QRISLandingInteractor.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Combine
import Foundation
import InjectorModule
import UtilityModule

protocol QRISLandingDataStore {
    var featureName: String? { get set }
}

protocol QRISLandingBusinessLogic {
    var presenter: QRISLandingPresentationLogic? { get set }
    
    func getInitialTransactionData()
    func confirmPayment(with transaction: Transaction)
}

class QRISLandingInteractor: QRISLandingBusinessLogic, QRISLandingDataStore {
    weak var presenter: QRISLandingPresentationLogic?
    var featureName: String?
    
    @UserDefault(.alreadySetInitTrxData) var alreadySetInitTrxData: Bool?
    @UserDefault(.transactionData) var transactionData: TransactionData?
    
    func getInitialTransactionData() {
        if !(alreadySetInitTrxData ?? false) {
            transactionData = .init(balance: 10750500.25, transactionHistory: [])
            alreadySetInitTrxData = true
        }
        presenter?.presentTransactionData(transactionData)
    }
    
    func confirmPayment(with transaction: Transaction) {
        var savedTransactionData = transactionData
        
        guard let balance = savedTransactionData?.balance,
              let amountToPay = transaction.amountToPay else { return }
        
        if balance >= amountToPay {
            let updatedBalance = balance - amountToPay
            savedTransactionData?.balance = updatedBalance
            savedTransactionData?.transactionHistory.append(transaction)
            transactionData = savedTransactionData
            presenter?.presentTransactionData(transactionData)
            presenter?.didPaymentSuccess()
        } else {
            presenter?.didPaymentFailed()
        }
    }
}
