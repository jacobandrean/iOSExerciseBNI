//
//  QRISLandingPresenter.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import Combine
import Foundation

protocol QRISLandingPresentationLogic: AnyObject {
    var viewController: QRISLandingDisplayLogic? { get set }
    var interactor: QRISLandingBusinessLogic? { get set }
    var router: QRISLandingRouting? { get set }
    
    func presentTransactionData(_ data: TransactionData?)
    func presentScanQR()
    func didTapConfirmPayment()
    func didPaymentSuccess()
    func didPaymentFailed()
    func flattenTransaction(_ transaction: Transaction) -> String
}

class QRISLandingPresenter: QRISLandingPresentationLogic {
    weak var viewController: QRISLandingDisplayLogic?
    var interactor: QRISLandingBusinessLogic?
    var router: QRISLandingRouting?
    private var transaction: Transaction?
    
    func presentTransactionData(_ data: TransactionData?) {
        guard let data else { return }
        viewController?.displayTransactionData(data)
    }
    
    func presentScanQR() {
        router?.showScanQRModal(delegate: self)
    }
    
    func didTapConfirmPayment() {
        guard let transaction else { return }
        interactor?.confirmPayment(with: transaction)
    }
    
    func didPaymentSuccess() {
        transaction = nil
        viewController?.displayPaymentSuccessAlert(title: "Payment Success")
    }
    
    func didPaymentFailed() {
        viewController?.displayPaymentFailedAlert(title: "Insufficient Balance", mesage: "Cannot confirm payment due to insufficient balance")
    }
    
    func flattenTransaction(_ transaction: Transaction) -> String {
        let merchantName = transaction.merchantName ?? ""
        let amount = transaction.$amountToPay
        
        let result = "\(merchantName) - \(amount)"
        return result
    }
}

extension QRISLandingPresenter: ScanQRDelegate {
    func didScanQRCodeWithData(_ data: String) {
        let trxData = data.components(separatedBy: ".")
        if trxData.count >= 4 {
            transaction = .init(destBank: trxData[0], trxID: trxData[1], merchantName: trxData[2], amountToPay: Decimal(string: trxData[3]))
        }
        
        guard let transaction else { return }
        
        let destBank = transaction.destBank ?? ""
        let trxID = transaction.trxID ?? ""
        let merchant = transaction.merchantName ?? ""
        let amount = transaction.$amountToPay
        let detail = "\(destBank)\n\(trxID)\n\(merchant)\n\(amount)"
        
        viewController?.displayTransactionDetail(detail)
    }
}
