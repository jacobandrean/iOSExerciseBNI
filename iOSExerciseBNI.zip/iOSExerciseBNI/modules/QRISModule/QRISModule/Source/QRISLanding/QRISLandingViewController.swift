//
//  QRISLandingViewController.swift
//  QRISModule
//
//  Created by J Andrean on 21/06/24.
//

import AVFoundation
import UIKit
import UIModule

protocol QRISLandingDisplayLogic: AnyObject {
    var interactor: QRISLandingBusinessLogic! { get set }
    var presenter: QRISLandingPresentationLogic! { get set }
    
    func displayTransactionData(_ data: TransactionData)
    func displayTransactionDetail(_ detail: String)
    func displayPaymentSuccessAlert(title: String)
    func displayPaymentFailedAlert(title: String, mesage: String)
}

class QRISLandingViewController: BaseVC {
    
    private let vStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .center
        stack.distribution = .fill
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    private var tableView: UITableView = {
        let tableView = UITableView()
//        tableView.register(PromoTableViewCell.self, forCellReuseIdentifier: PromoTableViewCell.reuseIdentifier)
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    private let scanQRStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.alignment = .fill
        stack.distribution = .fill
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    private let balanceLabel: UILabel = {
        let label = UILabel()
        label.text = "Balance: "
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let scanQRButton: UIButton = {
        let button = UIButton()
        button.setTitle("Scan QR", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let trxDetailLabel: UILabel = {
        let label = UILabel()
        label.isHidden = true
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let confirmPaymentButton: UIButton = {
        let button = UIButton()
        button.isHidden = true
        button.setTitle("Confirm Payment", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private lazy var dataSource: UITableViewDiffableDataSource<Int, Transaction> = {
        let dataSource = UITableViewDiffableDataSource<Int, Transaction>(tableView: tableView) { [weak self] tableView, indexPath, item in
            guard let self else { return UITableViewCell() }
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = presenter.flattenTransaction(item)
            cell.textLabel?.numberOfLines = 0
            return cell
        }
        return dataSource
    }()
    
    var interactor: QRISLandingBusinessLogic!
    var presenter: QRISLandingPresentationLogic!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        interactor.getInitialTransactionData()
        setupViews()
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        tableView.delegate = self
        view.addSubview(vStackView)
        vStackView.addArrangedSubview(trxDetailLabel)
        vStackView.addArrangedSubview(confirmPaymentButton)
        view.addSubview(tableView)
        view.addSubview(scanQRStack)
        scanQRStack.addArrangedSubview(balanceLabel)
        scanQRStack.addArrangedSubview(scanQRButton)
        
        NSLayoutConstraint.activate {
            vStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16)
            vStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16)
            vStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
            
            tableView.topAnchor.constraint(equalTo: vStackView.bottomAnchor, constant: 16)
            tableView.bottomAnchor.constraint(equalTo: scanQRStack.topAnchor, constant: -16)
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            
            scanQRStack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
            scanQRStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16)
            scanQRStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
            
            scanQRButton.heightAnchor.constraint(equalToConstant: 30)
            scanQRButton.widthAnchor.constraint(equalToConstant: 100)
            
            confirmPaymentButton.widthAnchor.constraint(equalToConstant: 160)
        }
        
        scanQRButton.addAction { [weak self] in
            self?.presenter.presentScanQR()
        }
        
        confirmPaymentButton.addAction { [weak self] in
            self?.presenter.didTapConfirmPayment()
        }
    }
    
    private func setupDataSourceSnapshot(with transactions: [Transaction]) {
        var snapshot = NSDiffableDataSourceSnapshot<Int, Transaction>()
        snapshot.appendSections([0])
        snapshot.appendItems(transactions, toSection: 0)
        DispatchQueue.main.async { [weak self] in
            self?.dataSource.apply(snapshot, animatingDifferences: false)
        }
    }
    
    private func showAlert(title: String, message: String? = nil) {
        let alert = UIAlertController(
            title: title,
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Okay", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

extension QRISLandingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel()
        label.textAlignment = .center
        label.backgroundColor = .lightGray
        label.text = "Transaction History"
        label.font = UIFont.boldSystemFont(ofSize: 18)
        return label
    }
}

extension QRISLandingViewController: QRISLandingDisplayLogic {
    func displayTransactionData(_ data: TransactionData) {
        balanceLabel.text = "Balance: \(data.$balance)"
        setupDataSourceSnapshot(with: data.transactionHistory)
    }
    
    func displayTransactionDetail(_ detail: String) {
        trxDetailLabel.text = detail
        trxDetailLabel.isHidden = false
        confirmPaymentButton.isHidden = false
    }
    
    func displayPaymentSuccessAlert(title: String) {
        trxDetailLabel.text = nil
        trxDetailLabel.isHidden = true
        confirmPaymentButton.isHidden = true
        showAlert(title: title)
    }
    
    func displayPaymentFailedAlert(title: String, mesage: String) {
        showAlert(title: title, message: mesage)
    }
}
