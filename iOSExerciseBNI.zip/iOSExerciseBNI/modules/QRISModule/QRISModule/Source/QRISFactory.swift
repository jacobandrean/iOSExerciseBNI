//
//  QRISFactory.swift
//  QRISModule
//
//  Created by J Andrean on 19/06/24.
//

import Foundation
import UIKit

public protocol QRISFactory {
    func createQRISLandingVC(featureName: String?) -> UIViewController
    func createScanQRVC(delegate: ScanQRDelegate?) -> UIViewController
}

struct QRISModuleFactory: QRISFactory {
    func createQRISLandingVC(featureName: String?) -> UIViewController {
        let viewController: UIViewController & QRISLandingDisplayLogic = QRISLandingViewController()
        let presenter: QRISLandingPresentationLogic = QRISLandingPresenter()
        var interactor: QRISLandingDataStore & QRISLandingBusinessLogic = QRISLandingInteractor()
        viewController.interactor = interactor
        viewController.presenter = presenter
        presenter.viewController = viewController
        presenter.interactor = interactor
        interactor.presenter = presenter
        interactor.featureName = featureName
        
        var router: QRISLandingRouting = QRISLandingRouter()
        router.baseVC = viewController
        presenter.router = router
        
        return viewController
    }
    
    func createScanQRVC(delegate: ScanQRDelegate?) -> UIViewController {
        let viewController: UIViewController & ScanQRDisplayLogic = ScanQRViewController()
        viewController.scanQRDelegate = delegate
        var presenter: ScanQRPresentationLogic = ScanQRPresenter()
        var interactor: ScanQRBusinessLogic = ScanQRInteractor()
        viewController.interactor = interactor
        viewController.presenter = presenter
        presenter.viewController = viewController
        interactor.presenter = presenter
        
        var router: ScanQRRouting = ScanQRRouter()
        router.baseVC = viewController
        presenter.router = router
        
        return viewController
    }
}
