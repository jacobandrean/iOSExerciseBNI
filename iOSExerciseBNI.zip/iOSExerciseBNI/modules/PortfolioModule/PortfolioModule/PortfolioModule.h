//
//  PortfolioModule.h
//  PortfolioModule
//
//  Created by J Andrean on 19/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for PortfolioModule.
FOUNDATION_EXPORT double PortfolioModuleVersionNumber;

//! Project version string for PortfolioModule.
FOUNDATION_EXPORT const unsigned char PortfolioModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PortfolioModule/PublicHeader.h>


