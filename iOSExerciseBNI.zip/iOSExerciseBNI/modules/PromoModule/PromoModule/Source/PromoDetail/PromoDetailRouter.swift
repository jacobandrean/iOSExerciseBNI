//
//  PromoDetailRouter.swift
//  PromoModule
//
//  Created by J Andrean on 20/06/24.
//

import Foundation
