//
//  PromoModule.h
//  PromoModule
//
//  Created by J Andrean on 19/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for PromoModule.
FOUNDATION_EXPORT double PromoModuleVersionNumber;

//! Project version string for PromoModule.
FOUNDATION_EXPORT const unsigned char PromoModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PromoModule/PublicHeader.h>


