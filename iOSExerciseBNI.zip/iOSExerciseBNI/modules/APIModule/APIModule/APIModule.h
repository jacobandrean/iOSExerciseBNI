//
//  APIModule.h
//  APIModule
//
//  Created by J Andrean on 19/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for APIModule.
FOUNDATION_EXPORT double APIModuleVersionNumber;

//! Project version string for APIModule.
FOUNDATION_EXPORT const unsigned char APIModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <APIModule/PublicHeader.h>


