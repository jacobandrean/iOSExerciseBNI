//
//  PropertyWrappers.swift
//  UtilityModule
//
//  Created by J Andrean on 21/06/24.
//

import Foundation

// MARK: - UserDefault
public enum UserDefaultKey: String {
    case transactionData
    case alreadySetInitTrxData
    case unknown
}

@propertyWrapper
public struct UserDefault<T: Codable> {
    let key: String
    
    public init(_ key: UserDefaultKey) {
        self.key = key.rawValue
    }
    
    public var wrappedValue: T? {
        get {
            guard let data = UserDefaults.standard.data(forKey: key) else {
                return nil
            }
            return try? JSONDecoder().decode(T.self, from: data)
        }
        
        set {
            guard let newValue else {
                UserDefaults.standard.removeObject(forKey: key)
                return
            }
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}


// MARK: - RupiahFormat
@propertyWrapper
public struct RupiahFormat: Codable {
    private var value: Decimal?
    
    public var wrappedValue: Decimal? {
        get { value }
        set {
            value = newValue
        }
    }

    public var projectedValue: String {
        guard let value else { return "Rp. 0" }
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = "Rp. "
        formatter.locale = Locale(identifier: "id_ID")
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 2
        return formatter.string(from: value as NSDecimalNumber) ?? ""
    }

    public init(wrappedValue: Decimal?) {
        self.value = wrappedValue
    }
    
    public init(wrappedValue: String) {
        self.value = Decimal(string: wrappedValue)
    }
}
