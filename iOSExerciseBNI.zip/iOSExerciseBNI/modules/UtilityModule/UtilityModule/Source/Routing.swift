//
//  Routing.swift
//  UtilityModule
//
//  Created by J Andrean on 19/06/24.
//

import Foundation
import UIKit

public enum RouteType {
    case push(animated: Bool)
    case present(animated: Bool)
    case replaceRoot(animated: Bool)
}

public enum RouteError: Error {
    case tryPushWhenMissingNavigation
    case tryReplaceWhenMissingNavigation
    case missingBaseVC
}

public protocol Routing {
    var baseVC: UIViewController? { get set }
}

public extension Routing {
    func route(_ type: RouteType, for viewController: UIViewController) throws {
        guard let baseVC = baseVC else { throw RouteError.missingBaseVC }
        
        switch type {
        case .push(animated: let animated):
            guard let navigation = baseVC.navigationController else { throw RouteError.tryPushWhenMissingNavigation }
            navigation.pushViewController(viewController, animated: animated)
        case .present(animated: let animated):
            baseVC.present(viewController, animated: animated)
        case .replaceRoot(animated: let animated):
            guard let navigation = baseVC.navigationController else { throw RouteError.tryReplaceWhenMissingNavigation }
            navigation.setViewControllers([viewController], animated: animated)
        }
    }
}
