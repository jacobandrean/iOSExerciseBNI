//
//  BaseVC.swift
//  UIModule
//
//  Created by J Andrean on 19/06/24.
//

import UIKit

open class BaseVC: UIViewController {
    
}
