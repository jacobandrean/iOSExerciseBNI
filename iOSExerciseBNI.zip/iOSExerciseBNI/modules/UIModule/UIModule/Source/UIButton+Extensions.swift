//
//  UIButton+Extensions.swift
//  UIModule
//
//  Created by J Andrean on 19/06/24.
//

import UIKit

extension UIButton {
    public func addAction(_ action: @escaping () -> Void, for event: UIControl.Event = .touchUpInside) {
        if #available(iOS 14.0, *) {
            addAction(UIAction { _ in action() }, for: event)
        } else {
            addTarget(self, action: #selector(handleAction(_:)), for: event)
        }
    }
    
    @objc private func handleAction(_ action: () -> Void) {
        action()
    }
}
