//
//  UIImageView+Extensions.swift
//  UIModule
//
//  Created by J Andrean on 20/06/24.
//

import Foundation
import UIKit

public extension UIImageView {
    func loadImage(from urlString: String, placeholder: UIImage? = nil) {
        self.image = placeholder
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                print("Failed to load image with error: \(error.localizedDescription)")
                return
            }
            
            guard let imageData = data else {
                print("No image data found")
                return
            }
            
            if let image = UIImage(data: imageData) {
                DispatchQueue.main.async {
                    self.image = image
                }
            } else {
                print("Failed to create image from data")
            }
        }
        
        task.resume()
    }
}
